import { createAdminClient } from "@/lib/supabase/admin"
import { LogoLockup } from "@/components/brand/logo"
import { tokenActive } from "@/lib/references/process"
import { CohabitantFlow } from "@/components/public/cohabitant-flow"

export const metadata = { title: "Cohabitant affidavit — Gun License NYC", robots: { index: false, follow: false } }

export default async function CohabitantPage({ params }: { params: Promise<{ token: string }> }) {
  const { token } = await params
  const admin = createAdminClient()

  const { data: cohab } = await admin
    .from("cohabitants")
    .select("id, name, relationship, affidavit_status, case_id, contact_email, token_expires_at, token_revoked_at, opened_at")
    .eq("token", token)
    .maybeSingle()

  if (!cohab || !tokenActive({ expires_at: cohab.token_expires_at, revoked_at: cohab.token_revoked_at })) {
    return (
      <Shell>
        <h1 className="text-xl font-semibold">This link isn&apos;t valid</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          The affidavit link may have expired or been mistyped. Please ask the applicant to resend it.
        </p>
      </Shell>
    )
  }

  const { data: kase } = await admin.from("cases").select("clients(full_name)").eq("id", cohab.case_id).single()
  const applicant = (kase?.clients as unknown as { full_name: string } | null)?.full_name ?? "the applicant"

  // First open leaves a trace — same journey tracking the reference flow has,
  // so the applicant can see "opened the link" instead of wondering.
  if (!cohab.opened_at) {
    await admin.from("cohabitants").update({ opened_at: new Date().toISOString() }).eq("id", cohab.id)
  }

  return (
    <Shell>
      <h1 className="text-xl font-semibold tracking-tight">Cohabitant affidavit</h1>
      <p className="mt-1 text-sm text-muted-foreground">
        A quick, guided confirmation for {applicant}&apos;s NYC carry-license application — no account needed.
        We&apos;ll build a notarization-ready affidavit from your confirmation.
      </p>
      <CohabitantFlow
        token={token}
        cohabitantName={cohab.name ?? ""}
        relationship={cohab.relationship ?? null}
        applicant={applicant}
        initialStatus={cohab.affidavit_status}
        invitedEmail={cohab.contact_email ?? ""}
      />
    </Shell>
  )
}

function Shell({ children }: { children: React.ReactNode }) {
  return (
    <div className="mx-auto min-h-svh w-full max-w-xl px-4 py-10">
      {/* UNBRAND DECISION: shown to a THIRD PARTY (an adult cohabitant) from an
          emailed link — kept branded on purpose so it doesn't read as phishing.
          The affidavit PDF they sign is unbranded (lib/pdf/builder); this page is not. */}
      <LogoLockup className="mb-6 text-lg" />
      {children}
    </div>
  )
}
