import { MapPin, Clock, ShieldCheck, Check } from "lucide-react"
import { createClient } from "@/lib/supabase/server"
import { createAdminClient } from "@/lib/supabase/admin"
import { getMyInstructor } from "@/lib/instructor"
import { backfillMatchesForInstructor } from "@/lib/marketplace/offers"
import { markFeedSeen } from "@/lib/instructors/feed-signal"
import { stageMeta, type CaseStageKey } from "@/config/stages"
import { Button } from "@/components/ui/button"
import { expressInterest, declineOffer } from "./actions"

export const metadata = { title: "Case feed" }

export default async function InstructorFeedPage() {
  const me = await getMyInstructor()

  // Match this instructor to any open offers they now qualify for (they may have
  // been verified, or the offer posted, after the last time matching ran). This
  // is what makes the feed reflect reality instead of a creation-time snapshot.
  // Service-role write = system-generated match rows, per the marketplace design.
  if (me?.verified) {
    try {
      await backfillMatchesForInstructor(createAdminClient(), me.id)
    } catch {
      // Never let a backfill hiccup blank the feed; existing matches still show.
    }
  }

  const supabase = await createClient()

  // Opening the feed IS the "I've seen these" signal — that's what clears the
  // green dot on the nav. Marked with the CALLER'S client so the auth.uid()-
  // scoped RPC runs and the watermark comes from the database clock; a
  // service-role call has no session, and an app-clock timestamp can land
  // before rows that already exist, leaving the dot stuck on.
  if (me) {
    try {
      await markFeedSeen(supabase, me.id)
    } catch {
      // A failed watermark update just means the dot lingers; never blank the feed.
    }
  }

  const { data: feed } = await supabase
    .from("instructor_offer_feed")
    .select("offer_id, type, jurisdiction, area_label, distance_mi, stage, needs_note, created_at, responded")
    .order("created_at", { ascending: false })

  const all = feed ?? []
  const fresh = all.filter((o) => o.responded == null)
  const interested = all.filter((o) => o.responded === "interested")

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">Case feed</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Local applicants who need help. You see the area and the need — never a
          name or address — until the applicant chooses you.
        </p>
      </div>

      {!me?.verified && (
        <div className="flex items-center gap-2 rounded-md border border-warn/30 bg-warn/10 px-4 py-3 text-sm text-warn">
          <ShieldCheck className="size-4" /> You&apos;ll see and respond to cases once an admin verifies you.
        </div>
      )}

      {interested.length > 0 && (
        <div>
          <h2 className="engraved mb-2 text-text-low">Awaiting the applicant</h2>
          <ul className="space-y-3">
            {interested.map((o) => (
              <li key={o.offer_id} className="rounded-lg border border-brass/25 bg-brass/5 p-4">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <div className="flex items-center gap-2 text-sm font-medium text-brass-bright">
                      <Check className="size-4" /> You&apos;re interested — awaiting their choice
                    </div>
                    <div className="mt-2 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-text-mid">
                      <span className="rounded bg-surface-2 px-2 py-0.5">
                        {o.type === "full_assist" ? "Full application help" : "18-hour training"}
                      </span>
                      <span className="flex items-center gap-1">
                        <MapPin className="size-3" /> {o.area_label ?? "NYC"}
                        {o.distance_mi != null && <span>· {Number(o.distance_mi).toFixed(1)} mi</span>}
                      </span>
                    </div>
                  </div>
                  <form action={declineOffer}>
                    <input type="hidden" name="offerId" value={o.offer_id ?? ""} />
                    <Button type="submit" size="sm" variant="ghost">Withdraw</Button>
                  </form>
                </div>
              </li>
            ))}
          </ul>
        </div>
      )}

      <div>
        {interested.length > 0 && <h2 className="engraved mb-2 text-text-low">New requests</h2>}
        {fresh.length === 0 ? (
          <p className="rounded-lg border border-dashed bg-card p-8 text-center text-sm text-muted-foreground">
            No new requests right now. We&apos;ll match you as local applicants request help.
          </p>
        ) : (
          <ul className="space-y-3">
            {fresh.map((o) => (
              <li key={o.offer_id} className="rounded-lg border bg-card p-4">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="rounded bg-surface-2 px-2 py-0.5 text-xs font-medium text-text-mid">
                        {o.type === "full_assist" ? "Full application help" : "18-hour training"}
                      </span>
                      <span className="text-xs uppercase tracking-wide text-text-low">{o.jurisdiction}</span>
                    </div>
                    <div className="mt-2 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-text-mid">
                      <span className="flex items-center gap-1">
                        <MapPin className="size-3" /> {o.area_label ?? "NYC"}
                        {o.distance_mi != null && <span>· {Number(o.distance_mi).toFixed(1)} mi</span>}
                      </span>
                      {o.stage && (
                        <span className="flex items-center gap-1">
                          <Clock className="size-3" /> {stageMeta(o.stage as CaseStageKey).label}
                        </span>
                      )}
                    </div>
                    {o.needs_note && <p className="mt-2 text-sm">{o.needs_note}</p>}
                  </div>
                </div>
                <div className="mt-3 flex items-center gap-2">
                  <form action={expressInterest}>
                    <input type="hidden" name="offerId" value={o.offer_id ?? ""} />
                    <Button type="submit" size="sm" disabled={!me?.verified}>I&apos;m interested</Button>
                  </form>
                  <form action={declineOffer}>
                    <input type="hidden" name="offerId" value={o.offer_id ?? ""} />
                    <Button type="submit" size="sm" variant="ghost">Dismiss</Button>
                  </form>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  )
}
