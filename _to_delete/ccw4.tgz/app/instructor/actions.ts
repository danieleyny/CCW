"use server"

import { revalidatePath } from "next/cache"
import { redirect } from "next/navigation"
import { z } from "zod"
import { createClient } from "@/lib/supabase/server"
import { createAdminClient } from "@/lib/supabase/admin"
import { requireRole } from "@/lib/auth"
import { logActivity } from "@/lib/activity"
import { geocodeNyc, boroughFromLatLng, BOROUGHS } from "@/lib/geo/nyc"
import {
  findVirtualCourseClaim,
  findBannedClaim,
  VIRTUAL_COURSE_MESSAGE,
  BANNED_CLAIM_MESSAGE,
} from "@/lib/instructors/profile"
import { myInstructorId } from "@/lib/instructor"

const boroughEnum = z.enum(BOROUGHS as unknown as [string, ...string[]])

// ── Public: instructor self-registration ─────────────────────────────────────
const registerSchema = z.object({
  name: z.string().min(2, "Enter your full name"),
  email: z.string().email("Enter a valid email"),
  password: z.string().min(8, "Use at least 8 characters"),
  phone: z.string().max(30).optional().or(z.literal("")),
  bio: z.string().max(1000).optional().or(z.literal("")),
  dcjsId: z.string().optional().or(z.literal("")),
  borough: boroughEnum,
  // Optional ZIP for a precise radius origin; borough is the coarse fallback.
  zip: z.string().max(10).optional().or(z.literal("")),
  radiusMi: z.coerce.number().int().min(1).max(100).default(25),
  price18hCents: z.coerce.number().int().min(0).optional(),
})

export type RegisterState = { error?: string }

export async function registerInstructor(
  _prev: RegisterState,
  formData: FormData
): Promise<RegisterState> {
  const parsed = registerSchema.safeParse({
    name: formData.get("name"),
    email: formData.get("email"),
    password: formData.get("password"),
    phone: formData.get("phone") ?? "",
    bio: formData.get("bio") ?? "",
    dcjsId: formData.get("dcjsId") ?? "",
    borough: formData.get("borough"),
    zip: formData.get("zip") ?? "",
    radiusMi: formData.get("radiusMi") ?? 25,
    price18hCents: formData.get("price18hDollars")
      ? Math.round(Number(formData.get("price18hDollars")) * 100)
      : undefined,
  })
  if (!parsed.success) return { error: parsed.error.issues[0]?.message ?? "Invalid input" }
  const input = parsed.data

  const admin = createAdminClient()
  const { data: created, error: userErr } = await admin.auth.admin.createUser({
    email: input.email,
    password: input.password,
    email_confirm: true,
    user_metadata: { full_name: input.name },
  })
  if (userErr || !created.user) {
    return { error: userErr?.message ?? "Could not create the account" }
  }

  // handle_new_user creates every new profile as 'client' (signup can't set a
  // role). Promote to 'instructor' with the service role — the only path that
  // may. If this fails, tear the account down rather than leave a stuck client.
  const { error: roleErr } = await admin
    .from("profiles")
    .update({ role: "instructor" })
    .eq("id", created.user.id)
  if (roleErr) {
    await admin.auth.admin.deleteUser(created.user.id)
    return { error: "Could not finish creating your instructor account." }
  }

  // ZIP wins (finer origin); borough is the coarse fallback if no/unknown ZIP.
  const geo = geocodeNyc({ zip: input.zip || undefined, borough: input.borough })
  const { error: insErr } = await admin.from("instructors").insert({
    profile_id: created.user.id,
    name: input.name,
    email: input.email,
    phone: input.phone || null,
    bio: input.bio || null,
    dcjs_id: input.dcjsId || null,
    service_radius_mi: input.radiusMi,
    price_18h_cents: input.price18hCents ?? null,
    lat: geo?.lat ?? null,
    lng: geo?.lng ?? null,
    jurisdictions: ["nyc"],
    verified: false,
  })
  if (insErr) {
    // Roll back the auth user so the email can be reused.
    await admin.auth.admin.deleteUser(created.user.id)
    return { error: insErr.message }
  }

  redirect("/auth/login?registered=instructor")
}

// ── Authed instructor: profile + locations ───────────────────────────────────
// (identity comes from lib/instructor.ts myInstructorId — profile_id-bound)

const optionalText = z.string().max(2000).optional().or(z.literal(""))
const checkbox = z
  .union([z.literal("on"), z.literal("true"), z.literal(""), z.undefined(), z.null()])
  .transform((v) => v === "on" || v === "true")

const profileSchema = z.object({
  bio: z.string().max(4000).optional().or(z.literal("")),
  phone: z.string().max(30).optional().or(z.literal("")),
  dcjsId: z.string().optional().or(z.literal("")),
  borough: boroughEnum,
  zip: z.string().max(10).optional().or(z.literal("")),
  radiusMi: z.coerce.number().int().min(1).max(100),
  price18hDollars: z.coerce.number().min(0).optional(),

  // About them — website is validated leniently (a bare domain is fine); we
  // normalize to a scheme before storing rather than rejecting "daniel.com".
  websiteUrl: z.string().max(300).optional().or(z.literal("")),
  instagramHandle: z.string().max(80).optional().or(z.literal("")),
  yearsExperience: z.coerce.number().int().min(0).max(70).optional(),
  background: optionalText,
  languages: optionalText, // comma-separated in the form, text[] in the DB

  // Their course
  classFormat: z.enum(["private_1on1", "small_group", "both"]).optional().or(z.literal("")),
  typicalClassSize: z.coerce.number().int().min(1).max(60).optional(),
  providesRange: z.enum(["yes", "no", ""]).optional(),
  separateRangeNote: optionalText,
  rangeFeeIncluded: checkbox,
  ammoIncluded: checkbox,
  materialsIncluded: checkbox,
  whatsToBring: optionalText,

  // Scheduling + availability
  schedulingNotes: optionalText,
  responseTimeNote: optionalText,
  offersIntroCall: checkbox,
  introCallNote: optionalText,
  classFrequency: z.enum(["weekly", "biweekly", "monthly", "bimonthly", ""]).optional(),
  openToMoreClasses: checkbox,
  // Consult window as hour-of-day integers (0–23 start, 1–24 end).
  consultHoursStart: z.coerce.number().int().min(0).max(23).optional(),
  consultHoursEnd: z.coerce.number().int().min(1).max(24).optional(),

  // Auto-offer
  autoOfferEnabled: checkbox,
  autoOfferNote: optionalText,
  autoOfferPriceDollars: z.coerce.number().min(0).optional(),
})

/**
 * Users type "daniel.com" or "www.eye-uni.com" without a scheme. Prepend
 * https:// so the stored value is a real, clickable URL. Returns null for empty
 * or clearly-unusable input (no dot, or contains a space).
 */
function normalizeUrl(raw?: string | null): string | null {
  const v = (raw ?? "").trim()
  if (!v) return null
  const withScheme = /^https?:\/\//i.test(v) ? v : `https://${v}`
  try {
    const u = new URL(withScheme)
    // Require a dotted host — rejects "https://foo" but accepts "foo.com".
    if (!u.hostname.includes(".")) return null
    return u.toString()
  } catch {
    return null
  }
}

/** Split "English, Spanish , ASL" into a clean array. */
const parseLanguages = (raw?: string | null): string[] =>
  (raw ?? "")
    .split(",")
    .map((l) => l.trim())
    .filter(Boolean)
    .slice(0, 12)

export type ProfileState = { error?: string; ok?: boolean }

export async function updateInstructorProfile(
  _prev: ProfileState,
  formData: FormData
): Promise<ProfileState> {
  await requireRole(["instructor"])
  const get = (k: string) => formData.get(k) ?? ""
  const parsed = profileSchema.safeParse({
    bio: get("bio"),
    phone: get("phone"),
    dcjsId: get("dcjsId"),
    borough: formData.get("borough"),
    zip: formData.get("zip") ?? "",
    radiusMi: formData.get("radiusMi"),
    price18hDollars: formData.get("price18hDollars") || undefined,
    websiteUrl: get("websiteUrl"),
    instagramHandle: get("instagramHandle"),
    yearsExperience: formData.get("yearsExperience") || undefined,
    background: get("background"),
    languages: get("languages"),
    classFormat: get("classFormat"),
    typicalClassSize: formData.get("typicalClassSize") || undefined,
    providesRange: get("providesRange"),
    separateRangeNote: get("separateRangeNote"),
    rangeFeeIncluded: formData.get("rangeFeeIncluded"),
    ammoIncluded: formData.get("ammoIncluded"),
    materialsIncluded: formData.get("materialsIncluded"),
    whatsToBring: get("whatsToBring"),
    schedulingNotes: get("schedulingNotes"),
    responseTimeNote: get("responseTimeNote"),
    offersIntroCall: formData.get("offersIntroCall"),
    introCallNote: get("introCallNote"),
    classFrequency: get("classFrequency"),
    openToMoreClasses: formData.get("openToMoreClasses"),
    consultHoursStart: formData.get("consultHoursStart") || undefined,
    consultHoursEnd: formData.get("consultHoursEnd") || undefined,
    autoOfferEnabled: formData.get("autoOfferEnabled"),
    autoOfferNote: get("autoOfferNote"),
    autoOfferPriceDollars: formData.get("autoOfferPriceDollars") || undefined,
  })
  if (!parsed.success) return { error: parsed.error.issues[0]?.message ?? "Invalid input" }
  const input = parsed.data

  // Days the instructor can be reached to consult — multi-value, validated
  // against the canonical set (Mon…Sun) so order is stable and no junk lands.
  const DAY_SET = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
  const selectedDays = new Set(formData.getAll("consultDays").map(String))
  const consultDays = DAY_SET.filter((d) => selectedDays.has(d))

  // A consult window must be a real range.
  if (
    input.consultHoursStart != null &&
    input.consultHoursEnd != null &&
    input.consultHoursEnd <= input.consultHoursStart
  ) {
    return { error: "Your consult end time must be after the start time." }
  }

  // COMPLIANCE: the required 18-hour course is in person under NY's CCIA. An
  // instructor may offer a free intro call remotely — never the course itself.
  // Checked across every free-text field an applicant would read.
  const applicantFacing = [input.bio, input.background, input.whatsToBring, input.schedulingNotes, input.introCallNote, input.autoOfferNote, input.separateRangeNote]
  for (const text of applicantFacing) {
    const virtual = findVirtualCourseClaim(text)
    if (virtual) return { error: `${VIRTUAL_COURSE_MESSAGE} (found: “${virtual.slice(0, 80)}”)` }
    const banned = findBannedClaim(text)
    if (banned) return { error: `${BANNED_CLAIM_MESSAGE} (found: “${banned}”)` }
  }

  const id = await myInstructorId()
  if (!id) return { error: "Instructor profile not found" }

  const supabase = await createClient()
  // ZIP wins for a precise radius origin. Without a ZIP, keep the point already on
  // file when the borough is unchanged — so editing an unrelated profile field
  // doesn't quietly snap a ZIP-precise center back to the borough centroid.
  let geo = geocodeNyc({ zip: input.zip || undefined, borough: input.borough })
  if (!input.zip) {
    const { data: cur } = await supabase.from("instructors").select("lat, lng").eq("id", id).maybeSingle()
    if (cur?.lat != null && cur?.lng != null && boroughFromLatLng(cur.lat, cur.lng) === input.borough) {
      geo = { lat: cur.lat, lng: cur.lng }
    }
  }
  const { error } = await supabase
    .from("instructors")
    .update({
      bio: input.bio || null,
      phone: input.phone || null,
      dcjs_id: input.dcjsId || null,
      service_radius_mi: input.radiusMi,
      price_18h_cents: input.price18hDollars != null ? Math.round(input.price18hDollars * 100) : null,
      lat: geo?.lat ?? null,
      lng: geo?.lng ?? null,

      website_url: normalizeUrl(input.websiteUrl),
      instagram_handle: input.instagramHandle || null,
      years_experience: input.yearsExperience ?? null,
      background: input.background || null,
      languages: parseLanguages(input.languages),

      class_format: input.classFormat || null,
      typical_class_size: input.typicalClassSize ?? null,
      // Tri-state on purpose: "not answered yet" is different from "no", and the
      // go-live checklist treats silence about the range as incomplete.
      provides_range: input.providesRange === "yes" ? true : input.providesRange === "no" ? false : null,
      separate_range_note: input.separateRangeNote || null,
      range_fee_included: input.rangeFeeIncluded,
      ammo_included: input.ammoIncluded,
      materials_included: input.materialsIncluded,
      whats_to_bring: input.whatsToBring || null,

      scheduling_notes: input.schedulingNotes || null,
      response_time_note: input.responseTimeNote || null,
      offers_intro_call: input.offersIntroCall,
      intro_call_note: input.introCallNote || null,
      class_frequency: input.classFrequency || null,
      open_to_more_classes: input.openToMoreClasses,
      consult_days: consultDays,
      consult_hours_start: input.consultHoursStart ?? null,
      consult_hours_end: input.consultHoursEnd ?? null,

      auto_offer_enabled: input.autoOfferEnabled,
      auto_offer_note: input.autoOfferNote || null,
      auto_offer_price_cents:
        input.autoOfferPriceDollars != null ? Math.round(input.autoOfferPriceDollars * 100) : null,
    })
    .eq("id", id)
  if (error) return { error: error.message }

  await logActivity({ action: "instructor.profile_updated", entity: "instructor", entityId: id })
  revalidatePath("/instructor")
  revalidatePath("/instructor/profile")
  return { ok: true }
}

export async function addTrainingLocation(formData: FormData) {
  await requireRole(["instructor"])
  const id = await myInstructorId()
  if (!id) throw new Error("Instructor profile not found")

  const label = String(formData.get("label") ?? "").trim()
  const address = String(formData.get("address") ?? "").trim()
  const borough = String(formData.get("borough") ?? "")
  const isRange = formData.get("isRange") === "on"
  if (!label) throw new Error("Label is required")

  const geo = geocodeNyc({ borough })
  const supabase = await createClient()
  const { error } = await supabase.from("training_locations").insert({
    instructor_id: id,
    label,
    address: address || null,
    is_range: isRange,
    lat: geo?.lat ?? null,
    lng: geo?.lng ?? null,
  })
  if (error) throw error
  revalidatePath("/instructor/profile")
}

export async function removeTrainingLocation(formData: FormData) {
  await requireRole(["instructor"])
  const locationId = String(formData.get("locationId") ?? "")
  const supabase = await createClient()
  const { error } = await supabase.from("training_locations").delete().eq("id", locationId)
  if (error) throw error
  revalidatePath("/instructor/profile")
}
