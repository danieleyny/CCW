import type { Metadata } from "next";
import { Geist, Space_Grotesk, JetBrains_Mono } from "next/font/google";
import "./globals.css";
import { brand } from "@/config/brand";
import { BrandStyle } from "@/config/brand-style";
import { Toaster } from "@/components/ui/sonner";
import { GoogleAnalytics } from "@/components/analytics/google-analytics";
import { WebVitals } from "@/components/analytics/web-vitals";

// Body + hero display fonts are on the critical path → preload. Mono is only
// small eyebrows/labels → keep it off the preload list so it doesn't compete
// with the LCP fonts. All swap so text paints immediately in the fallback.
const fontSans = Geist({
  variable: "--font-sans",
  subsets: ["latin"],
  display: "swap",
});

const fontDisplay = Space_Grotesk({
  variable: "--font-display",
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  display: "swap",
});

const fontMono = JetBrains_Mono({
  variable: "--font-mono",
  subsets: ["latin"],
  display: "swap",
  preload: false,
});

// Search Console / Bing verification tokens are wired to env so the owner can
// verify ownership WITHOUT a code change: set the var in Vercel and redeploy.
// (DNS/HTML-file verification also works; this is the meta-tag path.)
const verification: Metadata["verification"] = {
  ...(process.env.NEXT_PUBLIC_GOOGLE_SITE_VERIFICATION
    ? { google: process.env.NEXT_PUBLIC_GOOGLE_SITE_VERIFICATION }
    : {}),
  ...(process.env.NEXT_PUBLIC_BING_SITE_VERIFICATION
    ? { other: { "msvalidate.01": process.env.NEXT_PUBLIC_BING_SITE_VERIFICATION } }
    : {}),
};

export const metadata: Metadata = {
  title: {
    default: `${brand.name} — ${brand.tagline}`,
    template: `%s · ${brand.name}`,
  },
  description: brand.description,
  metadataBase: new URL(brand.url),
  alternates: {
    types: { "application/rss+xml": [{ url: "/feed.xml", title: `${brand.name} — Guides` }] },
  },
  ...(Object.keys(verification).length ? { verification } : {}),
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="en"
      className={`${fontSans.variable} ${fontDisplay.variable} ${fontMono.variable} h-full antialiased`}
    >
      <head>
        <BrandStyle />
      </head>
      <body className="relative min-h-full flex flex-col">
        {/* V3-P4.5 — keyboard users skip straight to content */}
        <a
          href="#main"
          className="sr-only z-50 rounded-md bg-brass px-3 py-2 text-sm font-medium text-brand-foreground focus:not-sr-only focus:absolute focus:left-3 focus:top-3"
        >
          Skip to content
        </a>
        {/* Every route group runs the dark register: marketing renders
            <DarkBackdrop /> in MarketingFrame, and the app groups render it
            inside their own `.dark` wrapper. */}
        <div id="main" className="contents">
          {children}
        </div>
        <Toaster richColors closeButton theme="dark" />
        {/* GA4 — only on the real production deployment, so localhost + preview
            traffic never pollutes the analytics. */}
        {process.env.VERCEL_ENV === "production" && (
          <>
            <GoogleAnalytics />
            <WebVitals />
          </>
        )}
      </body>
    </html>
  );
}
